import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { History, RotateCcw, Trophy } from 'lucide-react'
import { useStore } from '../../store/useStore'
import { useToast } from '../common/Toast'
import { ConfirmModal } from '../common/Modal'
import CategoryBadge from '../common/CategoryBadge'

export default function HistoryList() {
  const { state, dispatch } = useStore()
  const toast = useToast()
  const [confirmId, setConfirmId] = useState(null)

  const concluidas = state.modalidades
    .filter(m => m.status === 'concluida')
    .sort((a, b) => b.ordem - a.ordem)

  const nomeTime = (id) => state.times.find(t => t.id === id)
  const nomeParticipante = (id) => state.participantes.find(p => p.id === id)?.nome || '?'

  const handleDesfazer = (id) => {
    dispatch({ type: 'DESFAZER_RESULTADO', payload: id })
    toast('Resultado desfeito', 'info')
  }

  const medalEmoji = (pos) => {
    if (pos === 1) return '🥇'
    if (pos === 2) return '🥈'
    if (pos === 3) return '🥉'
    return `${pos}º`
  }

  return (
    <div className="bg-white/5 border border-white/10 rounded-2xl p-5">
      <div className="flex items-center gap-2 mb-4">
        <History className="w-5 h-5 text-green-400" />
        <h2 className="text-lg font-bold">Histórico</h2>
        <span className="ml-auto text-xs bg-green-500/20 text-green-300 px-2 py-0.5 rounded-full">{concluidas.length}</span>
      </div>

      {concluidas.length === 0 ? (
        <p className="text-sm text-gray-500 italic text-center py-4">Nenhuma modalidade concluída ainda</p>
      ) : (
        <div className="space-y-3">
          <AnimatePresence>
            {concluidas.map(m => (
              <motion.div
                key={m.id}
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="bg-white/5 border border-white/5 rounded-xl p-3"
              >
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div>
                    <p className="text-sm font-semibold text-white">{m.nome}</p>
                    <CategoryBadge categoria={m.categoria} especial={m.especial} />
                  </div>
                  <button
                    onClick={() => setConfirmId(m.id)}
                    className="flex items-center gap-1 text-xs text-gray-400 hover:text-orange-400 transition-colors shrink-0 px-2 py-1 rounded-lg hover:bg-orange-500/10"
                  >
                    <RotateCcw className="w-3.5 h-3.5" /> Desfazer
                  </button>
                </div>

                {m.resultado && (
                  <div className="space-y-1 mt-2">
                    {[...m.resultado]
                      .sort((a, b) => a.posicao - b.posicao)
                      .map(r => {
                        const time = nomeTime(r.timeId)
                        if (!time) return null
                        return (
                          <div key={r.timeId} className="flex items-center gap-2">
                            <span className="text-sm w-6">{medalEmoji(r.posicao)}</span>
                            <div className="w-2 h-2 rounded-full shrink-0" style={{ background: time.cor }} />
                            <span className="text-xs text-gray-300 flex-1">{time.nome}</span>
                            <span className="text-xs font-bold" style={{ color: time.cor }}>+{r.pontos}pts</span>
                          </div>
                        )
                      })}
                  </div>
                )}
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}

      <ConfirmModal
        open={!!confirmId}
        onClose={() => setConfirmId(null)}
        onConfirm={() => handleDesfazer(confirmId)}
        title="Desfazer resultado"
        message="Tem certeza? O resultado será removido e a modalidade voltará para a fila."
        confirmLabel="Desfazer"
        danger
      />
    </div>
  )
}
