import { motion } from 'framer-motion'
import { Clock, Users } from 'lucide-react'
import { useStore } from '../../store/useStore'
import CategoryBadge from '../common/CategoryBadge'

export default function UpcomingModalities() {
  const { state } = useStore()

  const pendentes = state.modalidades
    .filter(m => m.status === 'pendente')
    .sort((a, b) => a.ordem - b.ordem)

  const nomeParticipante = (id) => state.participantes.find(p => p.id === id)?.nome || '?'
  const nomeTime = (id) => state.times.find(t => t.id === id)

  return (
    <div className="bg-white/5 border border-white/10 rounded-2xl p-5">
      <div className="flex items-center gap-2 mb-4">
        <Clock className="w-5 h-5 text-blue-400" />
        <h2 className="text-lg font-bold">Próximas Modalidades</h2>
        <span className="ml-auto text-xs bg-blue-500/20 text-blue-300 px-2 py-0.5 rounded-full">{pendentes.length}</span>
      </div>

      {pendentes.length === 0 ? (
        <p className="text-sm text-gray-500 italic text-center py-4">Todas as modalidades foram realizadas!</p>
      ) : (
        <div className="space-y-3">
          {pendentes.map((m, idx) => {
            const timesParticipantes = m.tipo === 'duelo' ? state.times.slice(0, 2) : state.times
            return (
              <motion.div
                key={m.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.05 }}
                className={`rounded-xl p-3 border ${idx === 0 ? 'border-indigo-500/50 bg-indigo-500/5' : 'border-white/5 bg-white/3'}`}
              >
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div>
                    <div className="flex items-center gap-2">
                      {idx === 0 && <span className="text-xs bg-indigo-500 text-white px-1.5 py-0.5 rounded font-medium">PRÓXIMA</span>}
                      <span className="text-sm font-semibold text-white">{m.nome}</span>
                    </div>
                    <div className="mt-1">
                      <CategoryBadge categoria={m.categoria} especial={m.especial} />
                    </div>
                  </div>
                  <span className="text-xs text-gray-500 shrink-0">#{m.ordem}</span>
                </div>

                <div className="space-y-1.5 mt-2">
                  {timesParticipantes.map(time => {
                    const escalados = m.escalacao[time.id] || []
                    return (
                      <div key={time.id} className="flex items-start gap-2">
                        <div className="flex items-center gap-1.5 shrink-0">
                          <div className="w-2 h-2 rounded-full mt-1" style={{ background: time.cor }} />
                          <span className="text-xs font-medium" style={{ color: time.cor }}>{time.nome}:</span>
                        </div>
                        <div className="flex flex-wrap gap-1">
                          {escalados.length > 0
                            ? escalados.map(pid => (
                                <span key={pid} className="text-xs bg-white/10 rounded px-1.5 py-0.5 text-gray-300">{nomeParticipante(pid)}</span>
                              ))
                            : <span className="text-xs text-gray-500 italic">Sem escalação</span>
                          }
                        </div>
                      </div>
                    )
                  })}
                </div>
              </motion.div>
            )
          })}
        </div>
      )}
    </div>
  )
}
